<?php
session_start();
include "databasecon.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email_cliente'] ?? '';
    $password = $_POST['password_cliente'] ?? '';

    $utilizador_encontrado = false;

    // 1. Verifica Cliente
    $stmt = $conn->prepare("SELECT * FROM Cliente WHERE email_cliente = ? AND password_cliente = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado && $resultado->num_rows === 1) {
        $cliente = $resultado->fetch_assoc();
        $_SESSION['utilizador_id'] = $cliente['id_cliente'];
        $_SESSION['utilizador_nome'] = $cliente['nome_cliente'];
        $_SESSION['tipoUtilizador'] = $cliente['id_tipo'];
        header("Location: catalogo.php");
        $utilizador_encontrado = true;
        exit;
    }

    // 2. Verifica Funcionario
    $stmt = $conn->prepare("SELECT * FROM Funcionario WHERE email_funcionario = ? AND password_funcionario = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado && $resultado->num_rows === 1) {
        $func = $resultado->fetch_assoc();
        $_SESSION['utilizador_id'] = $func['id_funcionario'];
        $_SESSION['utilizador_nome'] = $func['nome_funcionario'];
        $_SESSION['tipoUtilizador'] = $func['id_tipo'];

        if ($func['id_tipo'] == 1) {
            header("Location: pagInicialAdmin.html");
        } elseif ($func['id_tipo'] == 2) {
            header("Location: pagInicialFunc.php");
        } else {
            echo "<script>alert('Tipo de funcionário desconhecido.'); window.location.href='login.html';</script>";
        }

        $utilizador_encontrado = true;
        exit;
    }

    // 3. Se não encontrou nenhum
    if (!$utilizador_encontrado) {
        echo "<script>alert('Utilizador não encontrado ou credenciais inválidas.'); window.location.href='login.html';</script>";
        exit;
    }
} else {
    header("Location: login.html");
    exit;
}
?>