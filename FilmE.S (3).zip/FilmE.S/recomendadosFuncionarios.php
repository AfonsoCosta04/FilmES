<?php
session_start();
include "databasecon.php";

// Apenas garante que há sessão
if (!isset($_SESSION['utilizador_id'])) {
    echo "<script>alert('Sessão expirada ou não iniciada.'); window.location.href='login.html';</script>";
    exit;
}

$id_funcionario = $_SESSION['utilizador_id']; // Usamos diretamente
$stmt = $conn->prepare("SELECT nome_funcionario FROM Funcionario WHERE id_funcionario = ?");
$stmt->bind_param("i", $id_funcionario);
$stmt->execute();
$res = $stmt->get_result();
$func = $res->fetch_assoc();

// Processa o formulário
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $filmesSelecionados = $_POST['filmes'] ?? [];

    if (count($filmesSelecionados) !== 5) {
        echo "<script>alert('Tens de selecionar exatamente 5 filmes.'); history.back();</script>";
        exit;
    }

    // Apaga recomendações anteriores
    $stmt = $conn->prepare("DELETE FROM recomendados_funcionario WHERE id_funcionario = ?");
    $stmt->bind_param("i", $id_funcionario);
    $stmt->execute();

    // Insere os 5 novos
    $stmt = $conn->prepare("INSERT INTO recomendados_funcionario (id_funcionario, id_filme) VALUES (?, ?)");
    foreach ($filmesSelecionados as $id_filme) {
        $stmt->bind_param("ii", $id_funcionario, $id_filme);
        $stmt->execute();
    }

    echo "<script>alert('Recomendações guardadas com sucesso!'); window.location.href='pagInicialFunc.php';</script>";
    exit;
}

// Busca os filmes
$result = $conn->query("SELECT id_filme, titulo, foto FROM Filme ORDER BY titulo ASC");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Escolher Recomendações</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .grid-filmes {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 30px;
        }
        .filme-card {
            text-align: center;
            background: #1b1b1b;
            border-radius: 8px;
            padding: 10px;
        }
        .filme-card img {
            width: 100%;
            height: auto;
            border-radius: 6px;
        }
        .filme-card input {
            margin-top: 10px;
        }
        .fundo-branco {
            background: white;
            padding: 50px;
            border-radius: 15px;
            margin: 30px;
        }
        .botao-voltar-edicao {
            position: relative;
            left: 40px;
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #ff5733, #ffbd33);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.4);
            transition: transform 0.2s ease-in-out;
            text-decoration: none;
            font-size: 20px;
            font-weight: bold;
            color: white;
            z-index: 10;
        }
        .recomendados-do-func {
            background: linear-gradient(45deg, #ff5733, #ffbd33);
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: none;
            padding: 10px 20px;
            border-radius: 30px;
            cursor: pointer;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease-in-out;
            text-transform: uppercase;
            letter-spacing: 1px;
            width: 200px;
            text-align: center;
        }

        /* Efeito hover no botão */
        .recomendados-do-func:hover {
            background: linear-gradient(45deg, #ffbd33, #ff5733);
            transform: scale(1.1);
        }
    </style>
</head>
<body>
<header>
    <div class="logo">
        <img src="imagens/FilmE.S..png" alt="Logo FILME.S">
    </div>
    <div class="role-admin">
        <p><strong><?= htmlspecialchars($func['nome_funcionario']) ?></strong></p>
    </div>
</header>
<main>
    <div class="background-image">
        
        <div class="fundo-branco">
            <form method="POST">
                <a href="pagInicialFunc.php" class="botao-voltar-edicao" title="Voltar ao painel inicial">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 18L9 12L15 6" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                </svg></a>
                <h2 style="text-align:center;color: black;">Seleciona <strong>exatamente</strong> 5 filmes recomendados</h2>
                <div class="grid-filmes">
                    
                    <?php while ($filme = $result->fetch_assoc()): ?>
                        <div class="filme-card">
                            <img src="<?= htmlspecialchars($filme['foto']) ?>" alt="<?= htmlspecialchars($filme['titulo']) ?>">
                            <p><?= htmlspecialchars($filme['titulo']) ?></p>
                            <input type="checkbox" name="filmes[]" value="<?= $filme['id_filme'] ?>">
                        </div>
                    <?php endwhile; ?>
                </div>
                <div style="text-align:center; margin-top: 20px;">
                    <button class="recomendados-do-func"type="submit">Guardar Recomendados</button>
                </div>
            </form>
        </div>
        <script>
            // Limita a 5 seleções
            const checkboxes = document.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(cb => {
                cb.addEventListener('change', () => {
                    const selecionados = document.querySelectorAll('input[type="checkbox"]:checked');
                    if (selecionados.length > 5) {
                        cb.checked = false;
                        alert("Só podes selecionar 5 filmes.");
                    }
                });
            });
        </script>
    </div>
</main>
</body>
</html>

