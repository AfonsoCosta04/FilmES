<?php
session_start();
include "databasecon.php";

// Verifica se o cliente tem sessão iniciada
if (!isset($_SESSION['utilizador_id']) || empty($_SESSION['utilizador_id'])) {
    echo "<script>
        alert('Sessão expirada ou não iniciada.');
        window.history.back();
    </script>";
    exit;
}

// Vai buscar os dados do cliente autenticado
$id_cliente = $_SESSION['utilizador_id'];
$stmt = $conn->prepare("SELECT * FROM cliente WHERE id_cliente = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<script>
        alert('Cliente não encontrado.');
        window.history.back();
    </script>";
    exit;
}

$cliente = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Editar Perfil</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body class="catalogo-body">
  <header>
    <a href="PagInicial.html">
      <div class="logo">
        <img src="imagens/FilmE.S..png" alt="Logo FILME.S">
      </div>
    </a>
    <nav>
      <ul>
        <li><a href="catalogo.php">Catálogo</a></li>
        <li><a href="localizacao.html">Localização</a></li>
      </ul>
    </nav>
    <div class="auth">
      <?php if (isset($_SESSION['utilizador_nome'])): ?>
        <span><?= htmlspecialchars($_SESSION['utilizador_nome']) ?></span>
      <?php endif; ?>
    </div>
  </header>

  <main>
    <div class="background-image">
      <div class="caixa-formulario-editar-func">
      <h2>Editar Perfil</h2>
      <form action="guardaAlteracaoPerfil.php" method="POST">
          <input type="hidden" name="id" value="<?= $cliente['id_cliente'] ?>">

          <label for="nome">Nome:</label>
          <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($cliente['nome_cliente']) ?>">

          <label for="email">Email:</label>
          <input type="email" id="email" name="email" value="<?= htmlspecialchars($cliente['email_cliente']) ?>">

          <label for="senha">Nova Password:</label>
          <input type="password" id="senha" name="senha">

          <label for="telefone">Telefone:</label>
          <input type="tel" id="telefone" name="telefone" value="<?= htmlspecialchars($cliente['numero_de_telefone']) ?>">

          <label for="contribuinte">NIF:</label>
          <input type="text" id="contribuinte" name="contribuinte" value="<?= htmlspecialchars($cliente['contribuinte']) ?>">

          <div class="botoes-edicao">
            <button type="button" class="botao-eliminar-func">Eliminar</button>
            <button type="submit" class="botao-confirmar-func">Confirmar</button>
          </div>
        </form>
      </div>
    </div>
</main>
<footer>
    <div class="social-links">
        <a href="#">Instagram</a>
        <a href="#">Twitter</a>
        <a href="#">Facebook</a>
    </div>
</footer>
</body>
</html>

  <footer>
    <div class="social-links">
      <a href="#">Instagram</a>
      <a href="#">Twitter</a>
      <a href="#">Facebook</a>
    </div>
  </footer>
</body>
</html>

