<?php
session_start();
include "databasecon.php";

if (!isset($_SESSION['utilizador_id'])) {
    echo "<script>alert('É necessário iniciar sessão.'); window.location.href='login.html';</script>";
    exit;
}

$id_cliente = $_SESSION['utilizador_id'];
$sql = "SELECT f.id_filme, f.titulo, f.foto, f.preco
        FROM carrinho c
        JOIN filme f ON f.id_filme = c.id_filme
        WHERE c.id_cliente = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$resultado = $stmt->get_result();

$filmes = [];
$total = 0;

while ($row = $resultado->fetch_assoc()) {
    $filmes[] = $row;
    $total += floatval($row['preco']);
}
?>


<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Carrinho</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body class="catalogo-body">

<header>
  <a href="PagInicial.html">
    <div class="logo">
      <img src="imagens/FilmE.S..png" alt="Logo FILME.S" height="40">
    </div>
  </a>
  <nav>
    <ul style="display: flex; list-style: none; gap: 15px;">
      <li><a href="catalogonovo.php">Catálogo</a></li>
      <li><a href="#">Localização</a></li>
    </ul>
  </nav>
  <div class="auth">
    <span><?= htmlspecialchars($_SESSION['utilizador_nome']) ?></span>
  </div>
</header>


  <main>
    <!-- Esquerda -->
    <div class="caixa-carrinho">
      <h2>Produtos no Carrinho</h2>

      <?php foreach ($filmes as $filme): ?>
      <div class="caixa-carrinho-produto">
        <div class="caixa-carrinho-imagem">
          <img src="<?= htmlspecialchars($filme['foto']) ?>" alt="<?= htmlspecialchars($filme['titulo']) ?>">
        </div>
        <div class="caixa-carrinho-descricao">
          <p><?= htmlspecialchars($filme['titulo']) ?> - <?= number_format($filme['preco'], 2, ',', '.') ?>€</p>
        </div>
      </div>
      <?php endforeach; ?>

      <div class="caixa-total">
        <span><strong>Total:</strong></span>
        <span class="preco-total"><?= number_format($total, 2, ',', '.') ?>€</span>
      </div>
    </div>

    <!-- Direita -->
    <div class="coluna-direita">
      <div class="caixa-info">
        <h2>Informações de Entrega</h2>
        <form action="guardarCompra.php" method="POST">
          <label for="dataLevantamento">Data de Levantamento:</label>
          <input type="date" id="dataLevantamento" name="dataLevantamento" required>

          <label for="dataEntrega">Data de Entrega:</label>
          <input type="date" id="dataEntrega" name="dataEntrega" required>

          <button class="botao-confirmar" type="submit">CONFIRMAR RESERVA</button>
        </form>

        <div class="localizacao-levantamento">
          <p><strong>Levantamento em:</strong> Av. do Empresário, Campus da Talagueira, 6000-767 Castelo Branco</p>
        </div>

        <div class="mapa-container">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1288.4453689532509!2d-7.51201423860533!3d39.81917484267759!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd3d5ea6bb2280e1%3A0x1c460157bc4b46c8!2sEscola%20Superior%20de%20Tecnologia%20-%20Instituto%20Polit%C3%A9cnico%20de%20Castelo%20Branco!5e0!3m2!1spt-PT!2spt!4v1742932596968!5m2!1spt-PT!2spt" 
            style="border:0; width: 100%; height: 100%; border-radius: 15px;" 
            allowfullscreen="" loading="lazy">
          </iframe>
        </div>
      </div>
    </div>
  </main>


<footer>
  <div class="social-links">
    <a href="#">Instagram</a>
    <a href="#">Twitter</a>
    <a href="#">Facebook</a>
  </div>
</footer>

</body>
</html>
