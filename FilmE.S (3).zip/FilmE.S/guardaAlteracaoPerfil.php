<?php
session_start();
require_once "databasecon.php";

if (!isset($_SESSION['utilizador_id'])) {
    echo "<script>alert('Sessão expirada ou não iniciada.'); window.location.href='login.html';</script>";
    exit;
}

$id_cliente = $_SESSION['utilizador_id'];

$updates = [];
$params = [];
$types = "";

// Email
if (!empty($_POST['email'])) {
    $updates[] = "email_cliente = ?";
    $params[] = $_POST['email'];
    $types .= "s";
}

// Nome
if (!empty($_POST['nome'])) {
    $updates[] = "nome_cliente = ?";
    $params[] = $_POST['nome'];
    $types .= "s";
}

// Password
if (!empty($_POST['senha']) && $_POST['senha'] !== "************") {
    $updates[] = "password_cliente = ?";
    $params[] = $_POST['senha'];
    $types .= "s";
}

// Telemóvel
if (!empty($_POST['telefone'])) {
    $updates[] = "numero_de_telefone = ?";
    $params[] = $_POST['telefone'];
    $types .= "s";
}

// Data de nascimento
if (!empty($_POST['nascimento'])) {
    $updates[] = "data_de_nasc_cliente = ?";
    $params[] = $_POST['nascimento'];
    $types .= "s";
}

// NIF
if (!empty($_POST['nif'])) {
    $updates[] = "contribuinte = ?";
    $params[] = $_POST['nif'];
    $types .= "s";
}

if (empty($updates)) {
    echo "<script>alert('Nenhuma alteração foi feita.'); window.location.href='perfil.php';</script>";
    exit;
}

$sql = "UPDATE Cliente SET " . implode(", ", $updates) . " WHERE id_cliente = ?";
$params[] = $id_cliente;
$types .= "i";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo "<script>alert('Alterações salvas com sucesso.'); window.location.href='perfil.php';</script>";
} else {
    echo "<script>alert('Erro ao salvar alterações: " . $conn->error . "'); window.location.href='perfil.php';</script>";
}
?>
