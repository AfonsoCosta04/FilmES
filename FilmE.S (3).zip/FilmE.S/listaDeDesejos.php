<?php
session_start();
include "databasecon.php";

if (!isset($_SESSION['utilizador_id'])) {
    echo "<script>alert('É necessário iniciar sessão.'); window.location.href='login.php';</script>";
    exit;
}

$id_cliente = $_SESSION['utilizador_id'];

// Busca os filmes da lista de desejos
$stmt = $conn->prepare("
    SELECT f.id_filme, f.titulo, f.foto, f.disponivel
    FROM listadesejos l
    JOIN filme f ON l.id_filme = f.id_filme
    WHERE l.id_cliente = ?
");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Lista de Desejos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<header>
    <a href="PagInicial.html">
        <div class="logo">
            <img src="imagens/FilmE.S..png" alt="Logo FILME.S">
        </div>
    </a>
    <nav>
        <ul>
            <li><a href="catalogonovo.html">Catálogo</a></li>
            <li><a href="#">Localização</a></li>
        </ul>
    </nav>
    <div class="auth">
        <?php if (isset($_SESSION['utilizador_nome'])): ?>
            <span><?= htmlspecialchars($_SESSION['utilizador_nome']) ?></span>
        <?php else: ?>
            <a href="login.php">Login</a> | <a href="signup.html">Sign Up</a>
        <?php endif; ?>
    </div>
</header>

<main>
    <div class="background-image">
        <section class="catalogo-filmes">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($filme = $result->fetch_assoc()): ?>
                    <div class="catalogo-filme">
                        <a href="produto.php?id_filme=<?= $filme['id_filme'] ?>" class="catalogo-link">
                            <img src="<?= htmlspecialchars($filme['foto']) ?>" alt="<?= htmlspecialchars($filme['titulo']) ?>">
                            <div class="catalogo-info">
                                <h3><?= htmlspecialchars($filme['titulo']) ?></h3>
                                <span class="catalogo-status">
                                    <?= $filme['disponivel'] ? '🟢 Disponível' : '🔴 Indisponível' ?>
                                </span>
                            </div>
                        </a>
                        <?php if ($filme['disponivel']): ?>
                            <a href="produto.php?id_filme=<?= $filme['id_filme'] ?>" class="catalogo-ver-filme disponivel">Ver Filme</a>
                        <?php else: ?>
                            <button class="catalogo-ver-filme indisponivel" disabled>Indisponível</button>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="text-align:center;">A sua lista de desejos está vazia.</p>
            <?php endif; ?>
        </section>
    </div>
</main>

<footer>
    <div class="social-links">
        <a href="#">Instagram</a>
        <a href="#">Twitter</a>
        <a href="#">Facebook</a>
    </div>
</footer>
</body>
</html>