<?php
require_once '../FilmE.S/databasecon.php';

$id_reserva = $_POST['id_reserva'] ?? null;
$acao = $_POST['acao'] ?? null;
$data_levantamento = $_POST['data_levantamento'] ?? null;
$data_entrega = $_POST['data_entrega'] ?? null;

if (!$id_reserva || !$acao) {
  http_response_code(400);
  echo 'Dados em falta';
  exit;
}

if ($acao === 'aceitar') {
  if (!$data_levantamento || !$data_entrega) {
    http_response_code(400);
    echo 'Datas em falta';
    exit;
  }

  $stmt = $conn->prepare("
    UPDATE aluguer 
    SET estado = 'aceite', data_levantamento = ?, data_devolucao = ?
    WHERE id_aluguer = ?
  ");
  $stmt->bind_param('ssi', $data_levantamento, $data_entrega, $id_reserva);
} elseif ($acao === 'rejeitar') {
  $stmt = $conn->prepare("
    UPDATE aluguer 
    SET estado = 'rejeitada' 
    WHERE id_aluguer = ?
  ");
  $stmt->bind_param('i', $id_reserva);
} else {
  http_response_code(400);
  echo 'Ação inválida';
  exit;
}

if ($stmt->execute()) {
  echo 'Sucesso';
} else {
  http_response_code(500);
  echo 'Erro ao atualizar';
}
?>
