<?php
require_once '../FilmE.S/databasecon.php'; // Caminho para a tua conexão

header('Content-Type: application/json');

$sql = "
  SELECT r.id_reserva, c.nome AS nome_cliente, GROUP_CONCAT(f.titulo SEPARATOR '||') AS filmes
  FROM reservas r
  JOIN clientes c ON r.id_cliente = c.id_cliente
  JOIN reserva_filme rf ON r.id_reserva = rf.id_reserva
  JOIN filmes f ON rf.id_filme = f.id_filme
  WHERE r.estado = 'pendente'
  GROUP BY r.id_reserva
";

$result = $conn->query($sql);

$dados = [];

while ($row = $result->fetch_assoc()) {
  $dados[] = [
    'id_reserva' => $row['id_reserva'],
    'nome_cliente' => $row['nome_cliente'],
    'filmes' => explode('||', $row['filmes'])
  ];
}

echo json_encode($dados);
?>
