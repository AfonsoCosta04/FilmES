package com.filmees.backend.controller;

import com.filmees.backend.model.Aluguer;
import com.filmees.backend.model.Carrinho;
import com.filmees.backend.model.Cliente;
import com.filmees.backend.model.Filme;
import com.filmees.backend.repository.*;
import com.filmees.backend.security.SecurityUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/alugueres")
@CrossOrigin(origins = "http://localhost:3000")
public class AluguerController {

    @Autowired
    private AluguerRepository aluguerRepository;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private FilmeRepository filmeRepository;

    @Autowired
    private CarrinhoFilmeRepository carrinhoFilmeRepository;

    @Autowired
    private CarrinhoRepository carrinhoRepository;

    @GetMapping
    public ResponseEntity<?> listarTodos(HttpServletRequest request) {
        if (!SecurityUtil.isFuncionario(request) && !SecurityUtil.isAdmin(request)) {
            return ResponseEntity.status(403).body("Acesso negado.");
        }
        return ResponseEntity.ok(aluguerRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Aluguer> obterPorId(@PathVariable Integer id) {
        Optional<Aluguer> aluguer = aluguerRepository.findById(id);
        return aluguer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/count/ativos/{idCliente}")
    public ResponseEntity<Long> countAtivos(@PathVariable Integer idCliente,
                                            HttpServletRequest request) {
        // só o próprio cliente pode ver
        Optional<Cliente> cliOpt = clienteRepository.findById(idCliente);
        if (cliOpt.isEmpty()) return ResponseEntity.notFound().build();
        if (!SecurityUtil.isProprio(request, cliOpt.get().getEmailCliente())) {
            return ResponseEntity.status(403).body(null);
        }

        // define quais estados contam como “ativos”
        var estadosAtivos = List.of("reservado", "alugado");
        long cnt = aluguerRepository
                .countByCliente_IdClienteAndEstadoIn(idCliente, estadosAtivos);
        return ResponseEntity.ok(cnt);
    }


    @Transactional
    @PostMapping
    public ResponseEntity<?> criarAluguer(@RequestBody Aluguer novoAluguer, HttpServletRequest request) {
        if (!SecurityUtil.isCliente(request)) {
            return ResponseEntity.status(403).body("Apenas clientes autenticados podem alugar filmes.");
        }

        Integer clienteId = SecurityUtil.getUserId(request);
        if (clienteId == null) {
            return ResponseEntity.status(401)
                    .body("Token inválido ou expirado.");
        }
        Optional<Cliente> clienteOpt = clienteRepository.findById(clienteId);
        if (clienteOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Cliente não encontrado.");
        }

        if (novoAluguer.getFilmes() == null || novoAluguer.getFilmes().isEmpty()) {
            return ResponseEntity.badRequest().body("É necessário pelo menos um filme.");
        }

        // Carregar filmes por ID (para evitar objetos incompletos)
        List<Integer> idsFilmes = novoAluguer.getFilmes().stream()
                .map(Filme::getIdFilme)
                .toList();

        List<Filme> filmesValidos = filmeRepository.findAllById(idsFilmes);

        if (filmesValidos.isEmpty()) {
            return ResponseEntity.badRequest().body("Filmes inválidos.");
        }

        var estadosAtivos = List.of("reservado", "alugado");
        long ativos = aluguerRepository
                .countByCliente_IdClienteAndEstadoIn(clienteOpt.get().getIdCliente(), estadosAtivos);

        if (ativos + novoAluguer.getFilmes().size() > 5) {
            return ResponseEntity
                    .badRequest()
                    .body("Limite de 5 filmes alugados simultaneamente excedido.");
        }

        novoAluguer.setCliente(clienteOpt.get());
        novoAluguer.setFilmes(filmesValidos);
        novoAluguer.setEstado("reservado");
        Carrinho carrinho = carrinhoRepository.findByIdCliente(clienteOpt.get().getIdCliente())
                .orElse(null);

        if (carrinho != null) {
            carrinhoFilmeRepository.deleteByCarrinhoIdCarrinho(carrinho.getIdCarrinho());
        }

        Aluguer aluguerGravado = aluguerRepository.save(novoAluguer);
        return ResponseEntity.ok(aluguerGravado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarAluguer(@PathVariable Integer id, HttpServletRequest request) {
        Optional<Aluguer> aluguer = aluguerRepository.findById(id);

        if (aluguer.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        boolean isProprio = SecurityUtil.isProprio(request, aluguer.get().getCliente().getEmailCliente());
        boolean isFuncionarioOuAdmin = SecurityUtil.isFuncionario(request) || SecurityUtil.isAdmin(request);

        if (!isProprio && !isFuncionarioOuAdmin) {
            return ResponseEntity.status(403).body("Acesso negado.");
        }

        aluguerRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/cliente/{id}")
    public ResponseEntity<?> listarPorCliente(@PathVariable Integer id, HttpServletRequest request) {
        Optional<Cliente> cliente = clienteRepository.findById(id);
        if (cliente.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        boolean isProprio = SecurityUtil.isProprio(request, cliente.get().getEmailCliente());
        boolean isFuncionarioOuAdmin = SecurityUtil.isFuncionario(request) || SecurityUtil.isAdmin(request);

        if (!isProprio && !isFuncionarioOuAdmin) {
            return ResponseEntity.status(403).body("Acesso negado.");
        }

        List<Aluguer> alugueres = aluguerRepository.findByCliente_IdCliente(id);
        return ResponseEntity.ok(alugueres);
    }

}
