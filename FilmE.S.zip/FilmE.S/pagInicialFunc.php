<?php
session_start();
if (!isset($_SESSION['utilizador_id']) || $_SESSION['tipoUtilizador'] != 2) {
    echo "<script>alert('Acesso negado.'); window.location.href='login.html';</script>";
    exit;
}

include 'databasecon.php';

$id_funcionario = $_SESSION['utilizador_id'];
$query = "SELECT * FROM Funcionario WHERE id_funcionario = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_funcionario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<script>alert('Funcionário não encontrado.'); window.location.href='login.html';</script>";
    exit;
}

$func = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FILME.S.</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/x-icon" href="imagens/favicon.ico">
</head>
<body>
<header>
    <div class="logo">
        <img src="imagens/FilmE.S..png" alt="Logo FILME.S">
    </div>
    <div class="role-admin">
        <p><strong><?= htmlspecialchars($func['nome_funcionario']) ?></strong></p>
    </div>
</header>
<main>
    <div class="background-image">
        <div class="opcao-gerir-admin-filme">
            

            <?php if ($func['perm_edicao']): ?>
            <div class="opcao-gerir-admin-alt">
                <a href="escolheFilmeMudar.php"><p>Editar Filme</p></a>
            </div>
            <?php endif; ?>

            <?php if ($func['perm_criacao']): ?>
            <div class="opcao-gerir-admin-alt">
                <a href="adicionarFilme.html"><p>Adicionar Filme</p></a>
            </div>
            <?php endif; ?>

            <div class="opcao-gerir-admin-alt">
                <a href="mudarEstado.php"><p>Alterar Disponibilidade</p></a>
            </div>

            <div class="opcao-gerir-admin-alt">
                <a href="recomendadosFuncionarios.php"><p>Recomendados</p></a>
            </div>
        </div>
    </div>
</main>

<footer>
    <div class="social-links">
        <a href="#">Instagram</a>
        <a href="#">Twitter</a>
        <a href="#">Facebook</a>
    </div>
</footer>
</body>
</html>