<?php
session_start();
require_once("databasecon.php");

if (!isset($_SESSION['utilizador_id'])) {
    echo "<script>alert('Sessão expirada ou não iniciada.'); window.history.back();</script>";
    exit;
}

$id_cliente = $_SESSION['utilizador_id'];
$id_filme = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id_filme <= 0) {
    echo "<script>alert('ID de filme inválido.'); window.history.back();</script>";
    exit;
}

// Verifica dados do filme
$stmt = $conn->prepare("SELECT idade_recomendada, disponivel FROM filme WHERE id_filme = ?");
$stmt->bind_param("i", $id_filme);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<script>alert('Filme não encontrado.'); window.history.back();</script>";
    exit;
}

$filme = $result->fetch_assoc();
$idade_recomendada = intval($filme['idade_recomendada']);
$disponivel = $filme['disponivel'];

if (!$disponivel) {
    echo "<script>alert('Filme indisponível.'); window.history.back();</script>";
    exit;
}

// Verifica idade do cliente
$stmt = $conn->prepare("SELECT data_de_nasc_cliente FROM cliente WHERE id_cliente = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<script>alert('Cliente não encontrado.'); window.history.back();</script>";
    exit;
}

$cliente = $result->fetch_assoc();
$birthdate = new DateTime($cliente['data_de_nasc_cliente']);
$today = new DateTime();
$idade_cliente = $today->diff($birthdate)->y;

if ($idade_cliente < $idade_recomendada) {
    echo "<script>alert('Não tem idade para alugar este filme.'); window.history.back();</script>";
    exit;
}

// Verifica número de filmes no carrinho
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM carrinho WHERE id_cliente = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
$total = $result->fetch_assoc()['total'];

if ($total >= 5) {
    echo "<script>alert('Já tem 5 filmes no carrinho.'); window.history.back();</script>";
    exit;
}

// Verifica se já está no carrinho
$stmt = $conn->prepare("SELECT * FROM carrinho WHERE id_cliente = ? AND id_filme = ?");
$stmt->bind_param("ii", $id_cliente, $id_filme);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<script>alert('Este filme já está no carrinho.'); window.history.back();</script>";
    exit;
}

// Adiciona ao carrinho
$stmt = $conn->prepare("INSERT INTO carrinho (id_cliente, id_filme) VALUES (?, ?)");
$stmt->bind_param("ii", $id_cliente, $id_filme);

if ($stmt->execute()) {
    header("Location: produto.php?id_filme=" . $id_filme);
    exit;
} else {
    echo "<script>alert('Erro ao adicionar ao carrinho.'); window.history.back();</script>";
    exit;
}
?>