<?php
session_start();
include "databasecon.php";

// Busca funcionários com exatamente 5 recomendações
$sql_funcionarios = "
    SELECT id_funcionario 
    FROM recomendados_funcionario 
    GROUP BY id_funcionario 
    HAVING COUNT(id_filme) = 5
";
$res_funcionarios = $conn->query($sql_funcionarios);

$dados = [];

while ($row = $res_funcionarios->fetch_assoc()) {
    $id_func = $row['id_funcionario'];

    // Buscar nome e foto do funcionário
    $stmt_nome = $conn->prepare("SELECT nome_funcionario  FROM Funcionario WHERE id_funcionario = ?");//tem que passar foto_funcionario também
    $stmt_nome->bind_param("i", $id_func);
    $stmt_nome->execute();
    $dados_func = $stmt_nome->get_result()->fetch_assoc();

    // Buscar os filmes recomendados
    $stmt_filmes = $conn->prepare("
        SELECT f.titulo, f.foto 
        FROM recomendados_funcionario rf
        JOIN Filme f ON f.id_filme = rf.id_filme
        WHERE rf.id_funcionario = ?
    ");
    $stmt_filmes->bind_param("i", $id_func);
    $stmt_filmes->execute();
    $filmes = $stmt_filmes->get_result()->fetch_all(MYSQLI_ASSOC);

    $dados[] = [
        'nome' => $dados_func['nome_funcionario'] ?? 'Funcionário Desconhecido',
        'foto' => $dados_func['foto_funcionario'] ?? 'imagens/default.jpg',
        'filmes' => $filmes
    ];
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Funcionários</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="icon" type="image/x-icon" href="imagens/favicon.ico">
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #000;
    }
    html, body {
      overflow-x: hidden;
    }
    .header-funcionarios-grid {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: #000;
      color: white;
      padding: 10px 30px;
    }
    .logo {
      flex: 1;
      display: flex;
      align-items: center;
    }
    .logo img {
      height: 40px;
    }
    .esquerda {
      flex: 10;
      text-align: left;
    }
    .direita {
      flex: 1;
      display: flex;
      justify-content: flex-end;
    }
    .esquerda a, .direita a {
      color: white;
      text-decoration: none;
      font-size: 16px;
      margin: 0 10px;
    }
    .esquerda a:hover, .direita a:hover {
      color: #FFD700;
    }
    .background-image {
      background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.65)),
      url('imagens/background.png') center/cover no-repeat;
      background-attachment: fixed;
      padding-top: 100px;
      padding-bottom: 80px;
      min-height: calc(100vh - 180px);
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .titulo-pagina {
      font-size: 32px;
      color: white;
      margin-bottom: 40px;
      font-weight: bold;
    }
    .funcionario {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: rgba(255, 255, 255, 0.9);
      width: 90%;
      max-width: 1000px;
      border-radius: 20px;
      padding: 15px 30px;
      margin-bottom: 25px;
      box-shadow: 0 0 12px rgba(0, 0, 0, 0.4);
    }
    .funcionario img.foto {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      object-fit: cover;
    }
    .funcionario .nome {
      flex-grow: 1;
      margin-left: 20px;
      font-size: 18px;
      font-weight: bold;
      color: #000;
    }
    .filmes-recomendados {
      display: flex;
      gap: 10px;
    }
    .filmes-recomendados img {
      width: 60px;
      height: 90px;
      object-fit: cover;
      border-radius: 10px;
    }
  </style>
</head>
<body>

  <header class="header-funcionarios-grid">
    <div class="logo">
      <a href="PagInicial.html"><img src="imagens/FilmE.S..png" alt="Logo FILME.S"></a>
    </div>
    <div class="esquerda">
      <a href="localizacao.html">Localização</a>
    </div>
    <div class="direita">
      <a href="carrinho.html">Carrinho</a> |
      <a href="perfil.html">Utilizador</a>
    </div>
  </header>

  <div class="background-image">
    <h2 class="titulo-pagina">Os Nossos Funcionários</h2>

    <?php foreach ($dados as $func): ?>
      <div class="funcionario">
        <!-- <img src="<?= htmlspecialchars($func['foto']) ?>" class="foto" alt="<?= htmlspecialchars($func['nome']) ?>"> -->
        <div class="nome"><?= htmlspecialchars($func['nome']) ?></div>
        <div class="filmes-recomendados">
          <?php foreach ($func['filmes'] as $filme): ?>
            <img src="<?= htmlspecialchars($filme['foto']) ?>" alt="<?= htmlspecialchars($filme['titulo']) ?>">
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <footer>
    <div class="social-links">
      <a href="#">Instagram</a>
      <a href="#">Twitter</a>
      <a href="#">Facebook</a>
    </div>
  </footer>

</body>
</html>