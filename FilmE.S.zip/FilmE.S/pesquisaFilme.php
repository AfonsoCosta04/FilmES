<?php
include "databasecon.php";

$titulo = $_GET['q'] ?? '';

if (empty($titulo)) {
    header("Location: catalogo.php");
    exit;
}

// Procura filme por título exato ou parcial
$stmt = $conn->prepare("SELECT id_filme FROM Filme WHERE titulo LIKE ? LIMIT 1");
$search = "%$titulo%";
$stmt->bind_param("s", $search);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $filme = $result->fetch_assoc();
    header("Location: produto.php?id_filme=" . $filme['id_filme']);
    exit;
} else {
    echo "<script>alert('Filme não encontrado.'); window.location.href='PagInicial.html';</script>";
    exit;
}
?>
