<?php
session_start();
require_once("databasecon.php");

// Verifica se o utilizador está autenticado
if (!isset($_SESSION['utilizador_id'])) {
    http_response_code(401);
    echo "É necessário iniciar sessão para adicionar aos desejos.";
    exit;
}

$id_cliente = $_SESSION['utilizador_id'];
$id_filme = isset($_GET['id_filme']) ? intval($_GET['id_filme']) : 0;

if ($id_filme <= 0) {
    http_response_code(400);
    echo "ID de filme inválido.";
    exit;
}

// Verifica se já está na lista
$sql_check = "SELECT * FROM listadesejos WHERE id_cliente = ? AND id_filme = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("ii", $id_cliente, $id_filme);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    header("Location: produto.php?id_filme=" . $id_filme);
    exit;
}

// Insere na lista
$sql = "INSERT INTO listadesejos (id_cliente, id_filme) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id_cliente, $id_filme);

if ($stmt->execute()) {
    header("Location: produto.php?id_filme=" . $id_filme);
    exit;
} else {
    echo "Erro ao adicionar: " . $conn->error;
}
?>