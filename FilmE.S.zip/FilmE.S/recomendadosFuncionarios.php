<?php
session_start();
include "databasecon.php";

// Apenas garante que há sessão
if (!isset($_SESSION['utilizador_id'])) {
    echo "<script>alert('Sessão expirada ou não iniciada.'); window.location.href='login.html';</script>";
    exit;
}

$id_funcionario = $_SESSION['utilizador_id']; // Usamos diretamente

// Processa o formulário
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $filmesSelecionados = $_POST['filmes'] ?? [];

    if (count($filmesSelecionados) !== 5) {
        echo "<script>alert('Tens de selecionar exatamente 5 filmes.'); history.back();</script>";
        exit;
    }

    // Apaga recomendações anteriores
    $stmt = $conn->prepare("DELETE FROM recomendados_funcionario WHERE id_funcionario = ?");
    $stmt->bind_param("i", $id_funcionario);
    $stmt->execute();

    // Insere os 5 novos
    $stmt = $conn->prepare("INSERT INTO recomendados_funcionario (id_funcionario, id_filme) VALUES (?, ?)");
    foreach ($filmesSelecionados as $id_filme) {
        $stmt->bind_param("ii", $id_funcionario, $id_filme);
        $stmt->execute();
    }

    echo "<script>alert('Recomendações guardadas com sucesso!'); window.location.href='pagInicialAdmin.html';</script>";
    exit;
}

// Busca os filmes
$result = $conn->query("SELECT id_filme, titulo, foto FROM Filme ORDER BY titulo ASC");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Escolher Recomendações</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .grid-filmes {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 30px;
        }
        .filme-card {
            text-align: center;
            background: #1b1b1b;
            border-radius: 8px;
            padding: 10px;
        }
        .filme-card img {
            width: 100%;
            height: auto;
            border-radius: 6px;
        }
        .filme-card input {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Seleciona exatamente 5 filmes recomendados</h2>

    <form method="POST">
        <div class="grid-filmes">
            <?php while ($filme = $result->fetch_assoc()): ?>
                <div class="filme-card">
                    <img src="<?= htmlspecialchars($filme['foto']) ?>" alt="<?= htmlspecialchars($filme['titulo']) ?>">
                    <p><?= htmlspecialchars($filme['titulo']) ?></p>
                    <input type="checkbox" name="filmes[]" value="<?= $filme['id_filme'] ?>">
                </div>
            <?php endwhile; ?>
        </div>
        <div style="text-align:center; margin-top: 20px;">
            <button type="submit">Guardar Recomendados</button>
        </div>
    </form>

    <script>
        // Limita a 5 seleções
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(cb => {
            cb.addEventListener('change', () => {
                const selecionados = document.querySelectorAll('input[type="checkbox"]:checked');
                if (selecionados.length > 5) {
                    cb.checked = false;
                    alert("Só podes selecionar 5 filmes.");
                }
            });
        });
    </script>
</body>
</html>

